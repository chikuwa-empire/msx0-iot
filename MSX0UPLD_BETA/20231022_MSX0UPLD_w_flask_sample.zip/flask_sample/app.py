from flask import Flask
from flask import request
from flask import render_template
import os

app = Flask(__name__)

@app.route('/')
def root():
    return '<p>Hello MSX0 Stack!</p>'

@app.route('/upload', methods=['POST', 'GET'])
def upload():
    if request.method == 'POST':
        filename = request.form['filename']
        data = request.form['filedata']
        if len(data) == 0:
            return 'EMPTY'
        s_pos = filename.rfind('\\')
        if s_pos > 0:
            filename = filename[s_pos + 1:]
        f = open(os.path.join('./static', filename), 'wb')
        for i in range(len(data) // 2):
            b = bytes.fromhex(data[i * 2] + data[i * 2 + 1])
            f.write(b)
        f.close()
        return 'OK'

# �ق�Ƃ�multipart�Ŏ�M����������
#        f = request.files['upload_file']
#        f.save(os.path.join('./static', f.filename))
#        return render_template('upload_form.html', msg=f.filename+' received.')
    else:
        return render_template('upload_form.html')

